## Запуск

- для запуска дев сервера - php artisan serve
- для запуска дев сервера фронта - npm run dev 
- для запуска очередей - php artisan queue:work -v
- для запуска reverb(штуки для websocket) - php artisan reverb:start


## Что еще сделать
- сделать форму для баг репортов

