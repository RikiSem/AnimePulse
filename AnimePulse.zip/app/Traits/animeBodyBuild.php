<?php

namespace App\Traits;

use App\Http\Classes\Reps\TagRep;
use App\Http\Classes\Season;
use App\Http\Classes\Storage;
use App\Models\Anime;
use Carbon\Carbon;
use Exception;
use Symfony\Component\HttpFoundation\File\File;

trait animeBodyBuild
{
    use ClearDescription;
    public static function prepareBody(Anime $anime, $responseData, TagRep $tagRep = new TagRep()): Anime
    {
        $anime->name = isset($responseData['russian']) ? $responseData['russian']: $responseData['japanese'];
        $anime->external_id = $responseData['id'];
        $anime->alter_names = json_encode([
            $responseData['english'],
            $responseData['japanese'],
            $responseData['synonyms'],
        ]);
        $anime->description = !empty($responseData['description']) ? self::clearDescription($responseData['description']) : $responseData['description'];

        $tags = [];
        foreach ($responseData['genres'] as $tag) {
            if ($tagRep->tagExist($tag['russian'])) {
                $tags[] = $tag['russian'];
            }
        }
        $anime->tags = json_encode($tags);

        $anime->release_date = null;
        $anime->release_day = (int)  $responseData['aired_on']['day'] ?? null;
        $anime->release_month = (int) $responseData['aired_on']['month'] ?? null;
        $anime->release_year = (int) $responseData['aired_on']['year'] ?? null;
        if ($anime->release_year && $anime->release_month && $anime->release_day) {
            $anime->release_date = Carbon::parse(sprintf(
                '%s.%s.%s',
                $responseData['aired_on']['day'],
                $responseData['aired_on']['month'],
                $responseData['aired_on']['year']
            ))->format('d.m.Y');
            $anime->season = sprintf(
                '%s-%s',
                Season::getSeasonByMonthNumber((int) $anime->release_month),
                $responseData['aired_on']['year']
            );
            $anime->in_current_season = Season::animeInCurrentSeason($anime->release_month, $anime->release_year);
        }
        

        $studios = [];
        foreach ($responseData['studios'] as $studio) {
            $studios[] = $studio['name'];
        }
        $anime->studio = json_encode($studios);

        $anime->type = $responseData['kind'];
        switch ($responseData['status']) {
            case 'FINISHED': 
                $status = Anime::SYSTEM_ANIME_STATUS_DONE;
                break;
            case 'RELEASING':
                $status = Anime::SYSTEM_ANIME_STATUS_ONGOING;
                break;
            case 'NOT_YET_RELEASED':
                $status = Anime::SYSTEM_ANIME_STATUS_ANNOUNCEMENT;
                break;
            case 'CANCELLED':
                $status = Anime::SYSTEM_ANIME_STATUS_CANCELED;
                break;
            case 'HIATUS':
                $status = Anime::SYSTEM_ANIME_STATUS_STOPPED;
                break;
        }
        $anime->status = $status;
        $anime->count_series = $responseData['episodes'];

        $posterRequest = $responseData['poster'];
        $anime->poster = Storage::DEFAULT_ANIME_POSTER;
        if (!empty($posterRequest) && !in_array('default.jpg', explode('/', $posterRequest))) {
            try {
                $poster = new File($posterRequest, false);
                $fileName = explode('?', $poster->getFilename())[0];
                file_put_contents(storage_path('app/public/imgs/posters/') . $fileName, file_get_contents($posterRequest));
                $anime->poster = $fileName;
            } catch (Exception $e) {
                $anime->poster = Storage::DEFAULT_ANIME_POSTER;
            } 
        }

        $anime->other_rates = number_format($responseData['score'] / 10);

        $anime->link_to_watch = '-';

        return $anime;
    }
}
