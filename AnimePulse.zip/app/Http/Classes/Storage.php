<?php


namespace App\Http\Classes;


class Storage
{
    public const POSTERS_PATH = '/../../storage/imgs/posters/';
    public const AVATAR_PATH = '/../../storage/imgs/avatars/';
    public const SYSTEM_IMG_PATH = '/../../storage/imgs/system/';
    public const DEFAULT_ANIME_POSTER = 'default.png';
}
